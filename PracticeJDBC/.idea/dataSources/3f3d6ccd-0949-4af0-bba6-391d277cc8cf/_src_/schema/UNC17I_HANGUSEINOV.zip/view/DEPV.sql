CREATE VIEW DEPV AS ( select lpad(' ', 3*level)||name as Tree,depart_id,PARENT_ID
from depart
start WITH parent_id is null
connect by prior depart_id=parent_id)
/
