CREATE VIEW ID_OTDEL_LOG AS (select depart_id from depart where name='Отдел логистики')
/
