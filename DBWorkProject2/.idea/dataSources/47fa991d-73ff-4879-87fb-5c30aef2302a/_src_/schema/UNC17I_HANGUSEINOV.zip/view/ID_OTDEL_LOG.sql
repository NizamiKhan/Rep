create view ID_OTDEL_LOG as
(select depart_id from depart where name='Отдел логистики')
